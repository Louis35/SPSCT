<h3>Menu action :</h3>
<div id="menu">
	<ul>
		<li><a href="index.php?pageId=setting">Paramètres</a></li>
		<li><a href="index.php?action=post_grade">Ajouter une notes</a></li>
	</ul>
</div>