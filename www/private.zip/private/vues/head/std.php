<head>
	<link rel="stylesheet" type="text/css" href="private/vues/styles/std.css">
	<meta charset="utf-8">
	<title><?php echo $title_head;?></title>
</head>