<h4>Séléctioner le paramètre à modifier :</h4>
<ul>
	<li>
		<a href="index.php?pageId=setting&amp;param=trimestre">
		Trimestre actuel (<?php echo $trimestre;?>)
		</a>
	</li>
	<li>
		<a href="index.php?pageId=setting&amp;param=objectif">
		Objectif (<?php echo $objectif;?>)
		</a>
	</li>
</ul>