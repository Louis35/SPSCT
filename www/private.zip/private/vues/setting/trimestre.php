<h4>Entrez la nouvelle valeur du trimestre</h4>
<form action="index.php?pageId=setting&amp;param=trimestre" method="post">
	<div>
		<input type="number" min="1" max="3" name="value">
	</div>
	<div>
		<input type="submit" value="Modifier" />
	</div>
</form>