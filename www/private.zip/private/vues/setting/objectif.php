<h4>Entrez la nouvelle valeur de votre objectif pour la trimestre :</h4>
<form action="index.php?pageId=setting&amp;param=objectif" method="post">
	<div>
		<input type="number" min="0" max="20" name="value">
	</div>
	<div>
		<input type="submit" value="Modifier" />
	</div>
</form>