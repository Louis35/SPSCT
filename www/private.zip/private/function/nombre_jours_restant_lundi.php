<?php
function nombre_jours_restant_lundi()
{
	return 8 - recup_day();
}